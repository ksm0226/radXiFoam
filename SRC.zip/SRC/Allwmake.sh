
NODE=4
if [[ $# -gt 0 ]] ; then
    echo " Node number supplied $1"
    NODE=$1
fi

declare -a REGIONS=(
    vaporInhomogeneousMixture
    laminarFlameSpeed
    radiation
    radXiFoam

)
for rgn in "${REGIONS[@]}"
do
    cd ${rgn}
    wmake -j${NODE}
    cd ..
done

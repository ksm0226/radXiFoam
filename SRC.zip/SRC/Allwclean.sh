
declare -a REGIONS=(
    vaporInhomogeneousMixture
    laminarFlameSpeed
    radiation
    radXiFoam

)
for rgn in "${REGIONS[@]}"
do
    cd ${rgn}
    wclean 
    cd ..
done

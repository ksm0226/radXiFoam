/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2004-2010 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
                            | Copyright (C) 2011-2017 OpenFOAM Foundation
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "vaporInhomogeneousMixture.H"
#include "fvMesh.H"

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

template<class ThermoType>
Foam::vaporInhomogeneousMixture<ThermoType>::vaporInhomogeneousMixture
(
    const dictionary& thermoDict,
    const fvMesh& mesh,
    const word& phaseName
)
:
    basicCombustionMixture
    (
        thermoDict,
        speciesTable({"ft", "b", "n2", "wv"}),
        mesh,
        phaseName
    ),

    stoicRatio_("stoichiometricAirFuelMassRatio", dimless, thermoDict),

    fuel_(thermoDict.subDict("fuel")),
    oxidant_(thermoDict.subDict("oxidant")),
    products_(thermoDict.subDict("burntProducts")),
    nitro_(thermoDict.subDict("Nitro")),
    waterVapor_(thermoDict.subDict("waterVapor")),
    

    mixture_("mixture", fuel_),

    ft_(Y("ft")),
    b_(Y("b")),
    n2_(Y("n2")),
    wv_(Y("wv"))
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template<class ThermoType>
const ThermoType& Foam::vaporInhomogeneousMixture<ThermoType>::mixture
(
    const scalar ft,
    const scalar b,
    const scalar n2,
    const scalar wv
    
) const
{ 
    
    
     
        scalar fu = b*ft + (1.0 - b)*fres(ft, stoicRatio().value());
        scalar ox = 1 - ft  - n2 - wv - (ft - fu)*stoicRatio().value();
        scalar pr = 1 - fu - ox - n2; //pr = wv + burntproduct
        
        
      
               
        mixture_ = fu*fuel_;
        mixture_ += ox*oxidant_;
        mixture_ += pr*products_;
        mixture_ += n2*nitro_;
        //mixture_ += wv*waterVapor_;
        
        return mixture_;
    
   
}

template<class ThermoType>
void Foam::vaporInhomogeneousMixture<ThermoType>::read(const dictionary& thermoDict)
{
    thermoDict.readEntry("stoichiometricAirFuelMassRatio", stoicRatio_);

    fuel_ = ThermoType(thermoDict.subDict("fuel"));
    oxidant_ = ThermoType(thermoDict.subDict("oxidant"));
    products_ = ThermoType(thermoDict.subDict("burntProducts"));
    nitro_ = ThermoType(thermoDict.subDict("Nitro"));
    waterVapor_ = ThermoType(thermoDict.subDict("waterVapor"));
}


template<class ThermoType>
const ThermoType& Foam::vaporInhomogeneousMixture<ThermoType>::getLocalThermo
(
    const label speciei
) const
{
    if (speciei == 0)
    {
        return fuel_;
    }
    else if (speciei == 1)
    {
        return oxidant_;
    }
    else if (speciei == 2)
    {
        return products_;
    }
    else if (speciei == 3)
    {
        return waterVapor_;
    }
   /* else if (speciei == 4)
    {
        return nitro;
    }*/
    
    else
    {
        FatalErrorInFunction
            << "Unknown specie index " << speciei << ". Valid indices are 0..2"
            << abort(FatalError);

        return fuel_;
    }
}


// ************************************************************************* //
